package com.fastv.app;
 
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.google.android.exoplayer2.*;
import com.google.android.exoplayer2.source.*;
import com.google.android.exoplayer2.source.hls.*;
import com.google.android.exoplayer2.trackselection.*;
import com.google.android.exoplayer2.ui.*;
import com.google.android.exoplayer2.upstream.*;
import com.google.android.exoplayer2.util.*;
import java.io.*;
import java.net.*;
import java.util.*;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import android.util.Log;
import java.text.SimpleDateFormat;
import android.preference.PreferenceManager;
import java.text.ParseException;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {

    PlayerView playerView;
    ProgressBar loading;
	
    private boolean playWhenReady = true;
    private int currentWindow = 0;
    private long playbackPosition = 0;
    
    ExoPlayer player;
	
    private List<Group> groupsList;
    private Map<Group, List<Channel>> channelsMap;
    private ArrayAdapter<Group> groupAdapter;
    private ChannelAdapter channelAdapter;
    private ListView listViewGroups;
    private ListView listViewChannels;
	
	private TextView textViewPing;
	private Handler handler = new Handler();
	private Runnable pingRunnable;
	
	DataSource.Factory dataSourceFactory;

	private Button btnToggleListView; 
	private View verticalLine3;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		
		//requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);
		
		InternetConnectionChecker checker = new InternetConnectionChecker(this);
		checker.checkInternetConnection();
		loadChannelsFromServer();
		
		boolean splashClassExists = isClassExists("com.fastv.app.HomeActivity");

		if (!splashClassExists) {
            finishAffinity();
        }
		
        playerView = findViewById(R.id.video_view);
        loading = findViewById(R.id.loading);
		
        hideSystemUI();
		
		textViewPing = findViewById(R.id.textViewPing);		
		
		btnToggleListView = findViewById(R.id.btnToggleListView);
		listViewGroups = findViewById(R.id.listViewGroups);
        listViewChannels = findViewById(R.id.listViewChannels);
		verticalLine3 = findViewById(R.id.verticalLine3);
		
        groupsList = new ArrayList<>();
        channelsMap = new HashMap<>();

        groupAdapter = new ArrayAdapter<>(this, R.layout.list_item_group, groupsList);
        channelAdapter = new ChannelAdapter(this, new ArrayList<>());

        listViewGroups.setAdapter(groupAdapter);
        listViewChannels.setAdapter(channelAdapter);

		// Defina a posição selecionada do canal como 0
		channelAdapter.setSelectedPosition(0);
		
        listViewGroups.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Group selectedGroup = groupsList.get(position);
                    loadChannelsForGroup(selectedGroup);
                }
            });
        // Configurar o listener de clique para o botão "Canais"
		btnToggleListView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					toggleListViews();
				}
			});

        // Configurar o listener de tecla para o botão "Canais"
		btnToggleListView.setOnKeyListener(new View.OnKeyListener() {
				@Override
				public boolean onKey(View v, int keyCode, KeyEvent event) {
					// Se a tecla enter ou espaço for pressionada, alternar a visibilidade das ListViews
					if (keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_SPACE) {
						if (event.getAction() == KeyEvent.ACTION_DOWN) {
							toggleListViews();
							return true;
						}
					}
					return false;
				}
			});

        // Configurar o listener de tecla para as ListViews
		listViewGroups.setOnKeyListener(new View.OnKeyListener() {
				@Override
				public boolean onKey(View v, int keyCode, KeyEvent event) {
					// Se a tecla para cima for pressionada na primeira posição da lista, focar no botão
					if (keyCode == KeyEvent.KEYCODE_DPAD_UP && event.getAction() == KeyEvent.ACTION_DOWN) {
						if (listViewGroups.getSelectedItemPosition() == 0) {
							btnToggleListView.requestFocus();
							return true;
						}
					}
					return false;
				}
			});
		
		// Configurar o listener de clique para os itens da lista de canais
		listViewChannels.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					Channel selectedChannel = channelAdapter.getItem(position);
					playChannel(selectedChannel);
					channelAdapter.setSelectedPosition(position);

					// Ocultar as ListViews ao selecionar um canal
					listViewGroups.setVisibility(View.GONE);
					listViewChannels.setVisibility(View.GONE);
					verticalLine3.setVisibility(View.GONE); 

					// Exibir o botão "Canais" novamente
					btnToggleListView.setVisibility(View.VISIBLE);
				}
			});
			
		pingRunnable = new Runnable() {
			@Override
			public void run() {
				performPing();
				handler.postDelayed(this, 1000); // Repetir a cada 1 segundo
			}
		};

		// Iniciar o primeiro ping
		handler.post(pingRunnable);
    }
	
	private void performPing() {
		new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						// IP ou URL para o qual você deseja pingar
						String ipAddress = "8.8.8.8"; // Google DNS
						InetAddress inet = InetAddress.getByName(ipAddress);

						long startTime = System.currentTimeMillis();
						boolean reachable = inet.isReachable(5000); // Timeout de 5 segundos
						long endTime = System.currentTimeMillis();
						final String latency = reachable ? (endTime - startTime) + "KB/S" : "0";

						// Atualizar o TextView na UI thread
						new Handler(getMainLooper()).post(new Runnable() {
								@Override
								public void run() {
									textViewPing.setText(latency);
								}
							});
					} catch (IOException e) {
						e.printStackTrace();
						new Handler(getMainLooper()).post(new Runnable() {
								@Override
								public void run() {
									textViewPing.setText("0");
								}
							});
					}
				}
			}).start();
	}
	
	private boolean isListViewOpen = false; // Variável para rastrear se a ListView está aberta

	@Override
	public void onBackPressed() {
		if (isListViewOpen) {
			// Se a ListView estiver aberta, feche-a e defina a variável isListViewOpen como false
			listViewChannels.setVisibility(View.GONE);
			listViewGroups.setVisibility(View.GONE);
			verticalLine3.setVisibility(View.GONE); 
			btnToggleListView.setVisibility(View.VISIBLE);
			isListViewOpen = false;
		} else {
			if (System.currentTimeMillis() - lastBackPressedTime < 2000) {
				// Se o botão de Voltar for pressionado novamente dentro de 2 segundos, exiba o Toast e feche o aplicativo
				super.onBackPressed(); // Fechar o aplicativo
			} else {
				// Se o botão de Voltar for pressionado pela primeira vez, defina o tempo atual e exiba o Toast
				Toast.makeText(this, "Pressione voltar novamente para ir ao inicio.", Toast.LENGTH_SHORT).show();
				lastBackPressedTime = System.currentTimeMillis();
			}
		}
	}

	private long lastBackPressedTime = 0; // Variável para rastrear o tempo do último pressionamento do botão de Voltar
	
	private void toggleListViews() {
		if (listViewGroups.getVisibility() == View.VISIBLE) {
			// Se as ListViews estiverem visíveis, oculte-as e atualize a variável isListViewOpen
			btnToggleListView.setVisibility(View.VISIBLE);
			listViewGroups.setVisibility(View.GONE);
			listViewChannels.setVisibility(View.GONE);
			verticalLine3.setVisibility(View.GONE); 
			isListViewOpen = false;
		} else {
			// Se as ListViews estiverem ocultas, exiba-as e atualize a variável isListViewOpen
			btnToggleListView.setVisibility(View.GONE);
			listViewGroups.setVisibility(View.VISIBLE);
			listViewChannels.setVisibility(View.VISIBLE);
			verticalLine3.setVisibility(View.VISIBLE); 
			isListViewOpen = true;
		}
	}
	
    private void loadChannelsFromServer() {
        final String canaisUrl = 配置讀取器.readCanaisUrl(getApplicationContext());
        new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        URL url = new URL(canaisUrl);

                        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                        connection.setRequestMethod("GET");

                        int responseCode = connection.getResponseCode();
                        if (responseCode == HttpURLConnection.HTTP_OK) {
                            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                            StringBuilder response = new StringBuilder();
                            String line;

                            while ((line = in.readLine()) != null) {
                                response.append(line);
                            }
                            in.close();

                            String json = response.toString();

                            // Processar o JSON e atualizar a UI aqui
                            try {
                                JSONObject jsonObject = new JSONObject(json);
                                JSONArray groupsArray = jsonObject.getJSONArray("groups");

                                for (int i = 0; i < groupsArray.length(); i++) {
                                    JSONObject groupObject = groupsArray.getJSONObject(i);
                                    String groupName = groupObject.getString("name");
                                    Group group = new Group(groupName);
                                    groupsList.add(group);

                                    JSONArray channelsArray = groupObject.getJSONArray("canais");
                                    List<Channel> channels = new ArrayList<>();
                                    for (int j = 0; j < channelsArray.length(); j++) {
                                        JSONObject channelObject = channelsArray.getJSONObject(j);
                                        String channelName = channelObject.getString("name");
                                        String channelUrl = channelObject.getString("url");
                                        String channelLogoUrl = channelObject.getString("logoUrl");
                                        Channel channel = new Channel(channelName, groupName, channelUrl, channelLogoUrl);
                                        channels.add(channel);
                                    }
                                    channelsMap.put(group, channels);
                                }

                                runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            groupAdapter.notifyDataSetChanged();

                                            // Selecionar o primeiro grupo
                                            if (!groupsList.isEmpty()) {
                                                Group firstGroup = groupsList.get(0);
                                                listViewGroups.performItemClick(
                                                    listViewGroups.getAdapter().getView(0, null, null),
                                                    0,
                                                    listViewGroups.getAdapter().getItemId(0)
                                                );
                                            }
                                        }
                                    });
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        } else {
                            // Tratar caso a resposta não seja OK (por exemplo, exibir uma mensagem de erro)                      
                           // Log.e("HTTP", "Erro ao obter o arquivo JSON do servidor. Código de resposta: " + responseCode);
                        }

                        connection.disconnect();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
    }
	
    private void loadChannelsForGroup(Group group) {
		channelAdapter.clear();
		List<Channel> channels = channelsMap.get(group);
		if (channels != null) {
			channelAdapter.addAll(channels);
		}
		channelAdapter.notifyDataSetChanged();

		if (channels != null && !channels.isEmpty()) {
			Channel firstChannel = channels.get(0);
			playChannel(firstChannel);
		} else {
			//Toast.makeText(this, "Nenhum canal disponível: " + group.getName(), Toast.LENGTH_SHORT).show();
		}
	}

	private void playChannel(Channel channel) {
		if (channel == null || channel.getUrl() == null || channel.getUrl().isEmpty()) {
			//Toast.makeText(this, "URL do canal não encontrada", Toast.LENGTH_SHORT).show();
			return;
		}

		String hls_url = channel.getUrl();
		Uri uri = Uri.parse(hls_url);

		Handler mainHandler = new Handler();
		MediaSource mediaSource = new HlsMediaSource.Factory(dataSourceFactory).createMediaSource(uri);

		if (player == null) {
			initializePlayer();
		}

		player.setPlayWhenReady(true);
		player.prepare(mediaSource);
	}

	private void initializePlayer() {
		TrackSelection.Factory adaptiveTrackSelection = new AdaptiveTrackSelection.Factory(new DefaultBandwidthMeter());
		player = ExoPlayerFactory.newSimpleInstance(
			new DefaultRenderersFactory(this),
			new DefaultTrackSelector(adaptiveTrackSelection),
			new DefaultLoadControl());

		playerView.setPlayer(player);
		DefaultBandwidthMeter defaultBandwidthMeter = new DefaultBandwidthMeter();
		dataSourceFactory = new DefaultDataSourceFactory(this, Util.getUserAgent(this, "Exo2"), defaultBandwidthMeter);

		// Aqui você pode definir uma URL padrão ou deixar vazia até selecionar um canal para reproduzir
		String hls_url = "";
		Uri uri = Uri.parse(hls_url);
		Handler mainHandler = new Handler();
		MediaSource mediaSource = new HlsMediaSource(uri, dataSourceFactory, mainHandler, null);
		player.prepare(mediaSource);
		player.setPlayWhenReady(playWhenReady);

		player.addListener(new Player.EventListener() {
				@Override
				public void onTimelineChanged(Timeline timeline, Object manifest, int reason) {
				}

				@Override
				public void onTracksChanged(TrackGroupArray trackGroups, TrackSelectionArray trackSelections) {
				}

				@Override
				public void onLoadingChanged(boolean isLoading) {
				}

				@Override
				public void onPlayerStateChanged(boolean playWhenReady, int playbackState) {
					switch (playbackState) {
						case ExoPlayer.STATE_READY:
							loading.setVisibility(View.GONE);
							break;
						case ExoPlayer.STATE_BUFFERING:
							loading.setVisibility(View.VISIBLE);
							break;
						case ExoPlayer.STATE_ENDED:
						case ExoPlayer.STATE_IDLE:
							// Se o player parou ou chegou ao fim, reinicie a reprodução
							playChannel(channelAdapter.getSelectedChannel());
							break;
					}
				}

				@Override
				public void onRepeatModeChanged(int repeatMode) {
				}

				@Override
				public void onShuffleModeEnabledChanged(boolean shuffleModeEnabled) {
				}

				@Override
				public void onPlayerError(ExoPlaybackException error) {
				}

				@Override
				public void onPositionDiscontinuity(int reason) {
				}

				@Override
				public void onPlaybackParametersChanged(PlaybackParameters playbackParameters) {
				}

				@Override
				public void onSeekProcessed() {
				}
			});
		player.seekTo(currentWindow, playbackPosition);
		player.prepare(mediaSource, true, false);
	}

	private void releasePlayer() {
		if (player != null) {
			playWhenReady = player.getPlayWhenReady();
			playbackPosition = player.getCurrentPosition();
			currentWindow = player.getCurrentWindowIndex();
			player.release();
			player = null;
		}
	}
	
	private boolean isClassExists(String className) {
        try {
            Class.forName(className);
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }
	
	private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN
        );
    }
	
	@Override
	protected void onStart() {
		super.onStart();
		if (Util.SDK_INT > 23) {
			initializePlayer();
		}
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		hideSystemUI();
		if ((Util.SDK_INT <= 23 || player == null)) {
			initializePlayer();
		}
	}

	@Override
	protected void onPause() {
		super.onPause();
		if (Util.SDK_INT <= 23) {
			releasePlayer();
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		}
	}

	@Override
	protected void onStop() {
		super.onStop();
		if (Util.SDK_INT > 23) {
			releasePlayer();
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		}
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		// Remover callbacks para evitar vazamentos de memória
		handler.removeCallbacks(pingRunnable);
	}
}
