package com.fastv.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;
import android.view.WindowManager;
import android.view.Window;

public class PinActivity extends Activity {

    private EditText pinInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_pin);

        hideSystemUI();

        pinInput = findViewById(R.id.pinInput);

        // Configurar os botões numéricos
        setNumericButtonListeners();
    }

    private void setNumericButtonListeners() {
        Button[] buttons = new Button[]{
            findViewById(R.id.button0),
            findViewById(R.id.button1),
            findViewById(R.id.button2),
            findViewById(R.id.button3),
            findViewById(R.id.button4),
            findViewById(R.id.button5),
            findViewById(R.id.button6),
            findViewById(R.id.button7),
            findViewById(R.id.button8),
            findViewById(R.id.button9),
            findViewById(R.id.buttonClear),
            findViewById(R.id.buttonSubmit)
        };

        for (final Button button : buttons) {
            button.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						switch (v.getId()) {
							case R.id.button0:
								appendToPin("0");
								break;
							case R.id.button1:
								appendToPin("1");
								break;
							case R.id.button2:
								appendToPin("2");
								break;
							case R.id.button3:
								appendToPin("3");
								break;
							case R.id.button4:
								appendToPin("4");
								break;
							case R.id.button5:
								appendToPin("5");
								break;
							case R.id.button6:
								appendToPin("6");
								break;
							case R.id.button7:
								appendToPin("7");
								break;
							case R.id.button8:
								appendToPin("8");
								break;
							case R.id.button9:
								appendToPin("9");
								break;
							case R.id.buttonClear:
								clearPin();
								break;
							case R.id.buttonSubmit:
								validatePin();
								break;
						}
					}
				});

            // Adiciona navegação com as teclas direcionais
            button.setOnKeyListener(new View.OnKeyListener() {
					@Override
					public boolean onKey(View v, int keyCode, android.view.KeyEvent event) {
						if (event.getAction() == android.view.KeyEvent.ACTION_DOWN) {
							if (keyCode == android.view.KeyEvent.KEYCODE_DPAD_CENTER || 
								keyCode == android.view.KeyEvent.KEYCODE_ENTER) {
								button.performClick();
								return true; // Evita a propagação do evento
							}
						}
						return false; // Não consome outros eventos de tecla
					}
				});
        }
    }

    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN
        );
    }

    private void appendToPin(String number) {
        String currentPin = pinInput.getText().toString();
        if (currentPin.length() < 4) {
            pinInput.setText(currentPin + number);
        }
    }

    private void clearPin() {
        pinInput.setText("");
    }

    private void validatePin() {
        String enteredPin = pinInput.getText().toString();
        String correctPin = "0000"; // Substitua por seu método de armazenamento

        if (enteredPin.equals(correctPin)) {
            Intent intent = new Intent(PinActivity.this, HotActivity.class);
            startActivity(intent);
            finish(); // Finaliza esta Activity se necessário
        } else {
            clearPin(); // Limpa o campo de entrada
            Toast.makeText(this, "PIN incorreto! Tente novamente.", Toast.LENGTH_SHORT).show();
        }
    }
}

