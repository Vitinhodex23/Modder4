package com.fastv.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class HomeActivity extends Activity {

    private Button buttonFastv;
    private Button buttonHot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Mantenha a tela ligada
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_home);

        hideSystemUI();

        // Inicializando os botões
        buttonFastv = findViewById(R.id.buttonFastv);
        buttonHot = findViewById(R.id.buttonHot);

        // Configurar o botão "Canais Fastv"
        buttonFastv.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					// Abre a Activity para Canais Fastv
					Intent intent = new Intent(HomeActivity.this, MainActivity.class);
					startActivity(intent);
				}
			});

        // Configurar o botão "Canais Hot"
        buttonHot.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					// Abre a Activity que pede o PIN
					Intent intent = new Intent(HomeActivity.this, PinActivity.class);
					startActivity(intent);
				}
			});

        // Adicionando um OnKeyListener para permitir navegação
        setNavigationListeners();
    }

    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
			View.SYSTEM_UI_FLAG_IMMERSIVE
			| View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
			| View.SYSTEM_UI_FLAG_FULLSCREEN
        );
    }

    private void setNavigationListeners() {
        View.OnKeyListener navigationListener = new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP) {
                    switch (keyCode) {
                        case KeyEvent.KEYCODE_DPAD_UP:
                            // Navegar para cima
                            if (v == buttonHot) {
                                buttonFastv.requestFocus();
                                return true;
                            }
                            break;
                        case KeyEvent.KEYCODE_DPAD_DOWN:
                            // Navegar para baixo
                            if (v == buttonFastv) {
                                buttonHot.requestFocus();
                                return true;
                            }
                            break;
                        case KeyEvent.KEYCODE_ENTER:
                        case KeyEvent.KEYCODE_DPAD_CENTER:
                            // Clicar no botão focado
                            if (v.isFocused()) {
                                v.performClick();
                                return true;
                            }
                            break;
                    }
                }
                return false;
            }
        };

        // Adicionando o OnKeyListener a cada botão
        buttonFastv.setOnKeyListener(navigationListener);
        buttonHot.setOnKeyListener(navigationListener);
    }
}
