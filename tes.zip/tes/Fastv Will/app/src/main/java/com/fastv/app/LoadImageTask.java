package com.fastv.app;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.widget.ImageView;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.HashMap;

public class LoadImageTask extends AsyncTask<String, Void, Bitmap> {

    private static Map<String, Bitmap> imageCache = new HashMap<>();
    private ImageView imageView;
    private String imageUrl;

    public LoadImageTask(ImageView imageView) {
        this.imageView = imageView;
    }

    @Override
    protected Bitmap doInBackground(String... urls) {
        imageUrl = urls[0];
        Bitmap bitmap = null;

        if (imageCache.containsKey(imageUrl)) {
            bitmap = imageCache.get(imageUrl);
        } else {
            try {
                URL url = new URL(imageUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setDoInput(true);
                connection.connect();
                InputStream input = connection.getInputStream();
                bitmap = BitmapFactory.decodeStream(input);
                if (bitmap != null) {
                    imageCache.put(imageUrl, bitmap); // Cache the image
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return bitmap;
    }

    @Override
    protected void onPostExecute(Bitmap result) {
        if (result != null && imageUrl.equals(imageView.getTag())) {
            imageView.setImageBitmap(result);
        }
    }
}
