package com.fastv.app;

import android.content.Context;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.InputStream;

public class 配置讀取器 {
 
    private static String jsonString = "{\"canaisUrl\": \"https://pastebin.com/raw/yL2ZzA8M\", \"hotUrl\": \"https://pastebin.com/raw/q331mgU5\"}";
	
    public static String readCanaisUrl(Context context) {
        return getUrlFromJson("canaisUrl");
    }

	public static String readHotUrl(Context context) {
        return getUrlFromJson("hotUrl");
    }
	
    private static String getUrlFromJson(String key) {
        String url = "";
        try {
            JSONObject jsonConfig = new JSONObject(jsonString);
            url = jsonConfig.getString(key);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return url;
    }
}
