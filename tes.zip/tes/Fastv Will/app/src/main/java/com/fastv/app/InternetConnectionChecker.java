package com.fastv.app;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.provider.Settings;
import android.app.AlertDialog;

public class InternetConnectionChecker {

    private Context context;

    public InternetConnectionChecker(Context context) {
        this.context = context;
    }

    // Método para verificar a conexão com a Internet
    public void checkInternetConnection() {
        if (!isInternetAvailable()) {
            showNoConnectionDialog();
        }
    }

    // Método que verifica se a Internet está disponível
    private boolean isInternetAvailable() {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isConnectedOrConnecting();
    }

    // Método que exibe o diálogo quando não há conexão
    private void showNoConnectionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Sem Conexão");
        builder.setMessage("Você está sem conexão com a Internet. Deseja abrir as configurações de Wi-Fi ou tentar novamente?");

        builder.setPositiveButton("Tentar Novamente", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					restartApp();
				}
			});

        builder.setNeutralButton("Configurações", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					context.startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
				}
			});

        AlertDialog dialog = builder.create();
        dialog.setCancelable(false);
        dialog.show();
    }

    // Método para reiniciar o aplicativo
    private void restartApp() {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            context.startActivity(intent);
        }
    }
}
