package com.fastv.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.view.View;

import android.widget.ProgressBar;
import android.widget.TextView;

public class SplashActivity extends Activity {

    private ProgressBar progressBar;
    private TextView progressPercentage;
    private int progressStatus = 0;
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Definir o layout da splash screen
        setContentView(R.layout.activity_splash);
		
		hideSystemUI();

        progressBar = findViewById(R.id.progressBar);
        progressPercentage = findViewById(R.id.progressPercentage);

        // Iniciar o carregamento
        loadSplashScreen();
    }

    private void loadSplashScreen() {
        // Simular carregamento em uma nova thread
        new Thread(new Runnable() {
				@Override
				public void run() {
					while (progressStatus < 100) {
						progressStatus += 1;
						handler.post(new Runnable() {
								@Override
								public void run() {
									// Atualiza a barra de progresso
									progressBar.setProgress(progressStatus);
									// Atualiza o texto de porcentagem
									progressPercentage.setText(progressStatus + "%");
								}
							});
						try {
							// Simular o tempo de carregamento (50ms para cada incremento)
							Thread.sleep(50);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					// Quando o progresso chegar a 100%, iniciar a próxima Activity
					if (progressStatus >= 100) {
						Intent intent = new Intent(SplashActivity.this, HomeActivity.class); // Substitua com sua MainActivity
						startActivity(intent);
						finish();
					}
				}
			}).start();
    }
	
	private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
			View.SYSTEM_UI_FLAG_IMMERSIVE
			| View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
			| View.SYSTEM_UI_FLAG_FULLSCREEN
        );
    }
}
