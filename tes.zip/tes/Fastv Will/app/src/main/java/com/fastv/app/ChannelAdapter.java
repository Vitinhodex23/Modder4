package com.fastv.app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;
import android.support.v4.content.ContextCompat;
import android.graphics.Color;

public class ChannelAdapter extends ArrayAdapter<Channel> {

    private LayoutInflater inflater;
    private int selectedPosition = -1;

    public ChannelAdapter(Context context, List<Channel> channels) {
        super(context, 0, channels);
        inflater = LayoutInflater.from(context);
    }

    public void setSelectedPosition(int position) {
        selectedPosition = position;
        notifyDataSetChanged();
    }

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.list_item_channel, parent, false);
			holder = new ViewHolder();
			holder.textViewNumber = convertView.findViewById(R.id.textViewChannelNumber);
			holder.imageView = convertView.findViewById(R.id.imageViewChannel);
			holder.textViewName = convertView.findViewById(R.id.textViewChannelName);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		Channel channel = getItem(position);
		if (channel != null) {
			holder.textViewName.setText(channel.getName());

			// Formata o número do canal com zeros à esquerda
			String channelNumber = String.format("%03d  ", position + 1);
			holder.textViewNumber.setText(channelNumber);

			String imageUrl = channel.getImageUrl();
			holder.imageView.setTag(imageUrl);
			new LoadImageTask(holder.imageView).execute(imageUrl);

			// Define a cor do texto para azul se o canal estiver selecionado
			if (position == selectedPosition) {
				holder.textViewName.setTextColor(Color.parseColor("#FFD700"));
			} else {
				// Define a cor do texto para branco se o canal não estiver selecionado
				holder.textViewName.setTextColor(Color.WHITE);
			}
		}

		return convertView;
	}

    public Channel getSelectedChannel() {
        if (selectedPosition != -1 && selectedPosition < getCount()) {
            return getItem(selectedPosition);
        } else {
            return null;
        }
    }

    private static class ViewHolder {
        TextView textViewNumber;
        ImageView imageView;
        TextView textViewName;
        TextView textViewWatchingIndicator;
    }
}
